CodeIgniter Indonesia Language Pack
==============================
Dukungan Bahasa Indonesia untuk CodeIgniter<br>
Versi CodeIgniter: 2.1.4<br>
Versi Paket Bahasa: 1.0

Instalasi:
==========
1. Download di https://github.com/masdevid/CodeIgniter-Indonesia-Langpack
2. Taruh folder <b>indonesia</b> pada direktori application/language
3. Ubah konfigurasi pada application/config/config.php <br>
   $config['language']	= 'indonesia';

Kontak Saya:
========
<b>Devid Haryalesmana</b><br> (devid.wahid@gmail.com)
